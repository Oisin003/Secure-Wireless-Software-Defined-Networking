# OpenFlow + Mininet Lab

## Files
- custom_topo.py: defines a simple topology with 2 switches (s1, s2) and 4 hosts (h1-h4).
- learning_firewall_ryu.py: Ryu controller implementing a learning switch with basic firewall rules.

## Usage

### Terminal 1: Start Ryu controller
ryu-manager --ofp-tcp-listen-port 6633 learning_firewall_ryu.py

### Terminal 2: Start Mininet
sudo mn --custom custom_topo.py --topo=mytopo --controller=remote,ip=127.0.0.1,port=6633 --switch=ovsk,protocols=OpenFlow13 --mac --arp

### Test Commands
mininet> pingall
mininet> h3 python3 -m http.server 80 &
mininet> h1 curl -sS 10.0.0.3 || echo "curl failed"
mininet> h1 ping -c3 10.0.0.3
mininet> h2 ping -c3 10.0.0.3

### Flow Table Check
sudo ovs-ofctl -O OpenFlow13 dump-flows s1
sudo ovs-ofctl -O OpenFlow13 dump-flows s2
